function [] = AOS_Finish()
% Function to finish AquaCrop-OS simulation and write outputs

%% Write outputs %%
AOS_WriteOutputs();

end

